# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['moleculelookup']

package_data = \
{'': ['*']}

install_requires = \
['click>=7.0,<8.0',
 'numpy>=1.17,<2.0',
 'pandas>=0.25.3,<0.26.0',
 'scipy>=1.3,<2.0',
 'sklearn>=0.0.0,<0.0.1']

entry_points = \
{'console_scripts': ['search_constants = moleculelookup.cli:search_constants']}

setup_kwargs = {
    'name': 'moleculelookup',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Kelvin',
    'author_email': 'kin.long.kelvin.lee@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
